// You can add here your extra plugins
module.exports = {
	paths: [
		// require('path').resolve(__dirname, './plugins/example/'),
	]
};
