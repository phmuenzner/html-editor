import Promise from './es6-promise';
Promise.polyfill();
export default Promise;
