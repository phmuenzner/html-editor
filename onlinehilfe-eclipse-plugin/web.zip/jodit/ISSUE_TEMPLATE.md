<!-- BUGS: Please use this template -->
<!-- QUESTIONS: This is not a general support forum! Ask Qs at http://stackoverflow.com/questions/tagged/jodit -->

**Jodit Version:**  3.2.xxxxx

**Browser:**  <!-- Chrome/IE/Safary/FF -->
**OS:**  <!-- Windows/Mac/Linux -->

**Code**

```js
// A *self-contained* demonstration of the problem follows...
```

**Expected behavior:**

**Actual behavior:**
